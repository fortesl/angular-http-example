module.exports = function(grunt) {

    grunt.initConfig({
        
        pkg: grunt.file.readJSON('package.json'),
        
        watch: {
            scripts: {
                files: ['src/**/*.js'],
                tasks: ['jshint']
            },
            stylesUI: {
                files: ['src/UI/**/*.css', 'src/UI/**/*.scss', '!src/UI/Content/css/style.css', '!src/UI/Content/css/all.min.css'],
                tasks: ['sass:devUI']
            },
        },

        sass: {
            devUI: {
                options: {
                    style: 'expanded'
                },
                files: {
                    'src/UI/Content/css/style.css': 'src/UI/Content/css/style.scss'
                }
            },
            ciUI: {
                options: {
                    style: 'compressed'
                },
                files: {
                    'src/UI/Content/css/style.css': 'src/UI/Content/css/style.scss'
                }
            }
        },

        jshint: {
            src: ['src/**/*.js', '!src/**/lib/*.js']
        },
        
        clean: {
            docs: 'docs',
            build: 'dev-build'
        },
        
        styleguide: {
            styledocco: {
                options: {
                    framework: {
                        name: 'styledocco'
                    }
                },
                files: {
                    'docs/styleguide': 'src/**/*.{scss,sass}'
                }
            }
        },
        
        useminPrepare: {
            html: 'src/UI/Features/Shared/_Layout.cshtml'
        },
        
        usemin: {
            html: ['src/UI/Features/Shared/_Layout.cshtml'],
            css: ['src/UI/Features/Shared/_Layout.cshtml']
        },

        cssmin: {
            combine: {
                files: {
                    'src/UI/Content/css/all.min.css': [
                        'src/UI/Content/css/lib/*.css',
                        'src/UI/Content/css/style.css'
                    ]
                }
            }
        },

        uglify: {
            options: {
              banner: '/*! <%= pkg.name %> <%= grunt.template.today("yyyy-mm-dd") %> */\n'
            },
            desk: {
              src: 'src/BondDesk.UI/Content/js/*.js',
              dest: 'dev-build/desk.min.js'
            },
            sman: {
                src: 'src/Bondsmen.UI/Content/js/*.js',
                dest: 'dev-build/smen.min.js'
            },
            desksman: {
                src: ['src/Bondsmen.UI/Content/js/*.js', 'src/Bondsmen.UI/Content/js/*.js'],
                dest: 'dev-build/desksmen.min.js'                
            },
            vendor: {
                src: ['src/vendor/js/*.js'],
                dest: 'dev-build/vendor.js'                
            }
          }        
    });
    
    // Tasks

    grunt.registerTask('dev', ['jshint', 'sass:devUI']);
    grunt.registerTask('ci', ['jshint', 'sass:ciUI', 'cssmin', 'usemin']);
    
    grunt.registerTask('default', ['clean', 'styleguide']);

    grunt.registerTask('buildjs', ['uglify:desksman']);
    grunt.registerTask('buildjs-desk', ['uglify:desk']);
    grunt.registerTask('buildjs-sman', ['uglify:sman']);
    grunt.registerTask('buildjs-vendor', ['uglify:vendor']);
    
    // Task Dependencies
    
    grunt.loadNpmTasks('grunt-contrib-jshint');
    grunt.loadNpmTasks('grunt-contrib-clean');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-contrib-sass');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-notify');
    grunt.loadNpmTasks('grunt-styleguide');
    grunt.loadNpmTasks('grunt-usemin');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    
};